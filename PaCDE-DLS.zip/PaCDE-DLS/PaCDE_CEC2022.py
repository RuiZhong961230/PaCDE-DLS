import os
from copy import deepcopy
import numpy as np
from opfunu.cec_based.cec2022 import *


PopSize = 50
DimSize = 10
LB = [-100] * DimSize
UB = [100] * DimSize
TrialRuns = 20
curFEs = 0
MaxFEs = DimSize * 1000

Pop = np.zeros((PopSize, DimSize))
FitPop = np.zeros(PopSize)
FuncNum = 0
BestPop = None
BestFit = float("inf")

H = 1
muF, muCr = [0.5] * H, [0.5] * H


# initialize the Pop randomly
def Initialization(func):
    global Pop, FitPop, curFEs, DimSize, BestPop, BestFit, H, muF, muCr
    H = 10
    muF, muCr = [0.5] * H, [0.5] * H
    for i in range(PopSize):
        for j in range(DimSize):
            Pop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
        FitPop[i] = func(Pop[i])
        # curFEs += 1
    BestFit = min(FitPop)
    BestPop = deepcopy(Pop[np.argmin(FitPop)])


def PaCDE(func):
    global Pop, FitPop, LB, UB, PopSize, DimSize, curFEs, BestPop, BestFit, curFEs, muF, muCr, H

    F_idx, Cr_idx = np.random.randint(H), np.random.randint(H)
    SF, SCr, Delta = [], [], []

    Off = np.zeros((PopSize, DimSize))
    FitOff = np.zeros(PopSize)

    for i in range(PopSize):
        IDX = np.random.randint(0, PopSize)
        while IDX == i:
            IDX = np.random.randint(0, PopSize)
        candi = list(range(0, PopSize))
        candi.remove(i)
        candi.remove(IDX)
        r1, r2 = np.random.choice(candi, 2, replace=False)

        F = np.clip(np.random.normal(muF[F_idx], 0.1), 0, 1)
        Cr = np.clip(np.random.normal(muCr[Cr_idx], 0.1), 0, 1)
        if FitPop[IDX] < FitPop[i]:  # DE/winner-to-best/1
            Off[i] = Pop[IDX] + F * (BestPop - Pop[IDX]) + F * (Pop[r1] - Pop[r2])
        else:
            Off[i] = Pop[i] + F * (BestPop - Pop[i]) + F * (Pop[r1] - Pop[r2])
        jrand = np.random.randint(0, DimSize)  # bin crossover
        for j in range(DimSize):
            if np.random.rand() < Cr or j == jrand:
                pass
            else:
                Off[i][j] = Pop[i][j]

        for j in range(DimSize):
            if Off[i][j] < LB[j] or Off[i][j] > UB[j]:
                Off[i][j] = np.random.uniform(LB[j], UB[j])

        FitOff[i] = func(Off[i])
        curFEs += 1
        if FitOff[i] < FitPop[i]:
            SF.append(F)
            SCr.append(Cr)
            Delta.append(FitPop[i] - FitOff[i])
            Pop[i] = deepcopy(Off[i])
            FitPop[i] = FitOff[i]
            if FitOff[i] < BestFit:
                BestFit = FitOff[i]
                BestPop = deepcopy(Off[i])

    if len(SF) == 0:
        pass
    else:
        muF[F_idx] = 0.9 * muF[F_idx] + 0.1 * meanWL(SF, Delta)
        muCr[Cr_idx] = 0.9 * muCr[Cr_idx] + 0.1 * meanWA(SCr, Delta)

    if curFEs > 0.8 * MaxFEs:
        sigma = np.random.rand()
        tau = 1 / np.sqrt(DimSize)
        for i in range(PopSize):
            Tmp = BestPop + sigma * np.random.uniform(-1, 1, DimSize)
            for j in range(DimSize):
                if Tmp[j] < LB[j] or Tmp[j] > UB[j]:
                    Tmp[j] = np.random.uniform(LB[j], UB[j])
            FitTmp = func(Tmp)
            curFEs += 1
            if FitTmp < BestFit:
                BestFit, BestPop = FitTmp, deepcopy(Tmp)
                sigma *= np.exp(tau * np.random.rand())
            else:
                sigma *= np.exp(-tau * np.random.rand())
    idx = np.argmin(FitPop)
    Pop[idx], FitPop[idx] = deepcopy(BestPop), BestFit


def meanWL(SF, Delta):
    numer = 0
    denom = 0
    sumDelta = sum(Delta)
    for i in range(len(SF)):
        numer += Delta[i] / sumDelta * SF[i] ** 2
        denom += Delta[i] / sumDelta * SF[i]
    return numer / denom


def meanWA(SCr, Delta):
    result = 0
    sumDelta = sum(Delta)
    for i in range(len(SCr)):
        result += Delta[i] / sumDelta * SCr[i]
    return result


def RunPaCDE(func):
    global curFEs, MaxFEs, TrialRuns, Pop, FitPop, DimSize, BestFit
    All_Trial_Best = []
    for i in range(TrialRuns):
        Best_list = []
        curFEs = 0
        np.random.seed(4399 + 13 * i)
        Initialization(func)
        Best_list.append(BestFit)
        while curFEs < MaxFEs:
            PaCDE(func)
            Best_list.append(BestFit)
        All_Trial_Best.append(Best_list)
    np.savetxt("./PaCDE_Data/CEC2022/F" + str(FuncNum) + "_" + str(DimSize) + "D.csv", All_Trial_Best, delimiter=",")


def main(Dim):
    global FuncNum, DimSize, Pop, MaxFEs, LB, UB
    DimSize = Dim
    Pop = np.zeros((PopSize, Dim))
    MaxFEs = Dim * 1000
    LB = [-100] * Dim
    UB = [100] * Dim
    CEC2022 = [F12022(Dim), F22022(Dim), F32022(Dim), F42022(Dim), F52022(Dim), F62022(Dim),
               F72022(Dim), F82022(Dim), F92022(Dim), F102022(Dim), F112022(Dim), F122022(Dim)]
    for i in range(len(CEC2022)):
        FuncNum = i + 1
        RunPaCDE(CEC2022[i].evaluate)


if __name__ == "__main__":
    if os.path.exists('./PaCDE_Data/CEC2022') == False:
        os.makedirs('./PaCDE_Data/CEC2022')
    Dims = [10, 20]
    for Dim in Dims:
        main(Dim)
